# AutoNova AI Online

این نسخه رایگان و آنلاین‌آماده است.

## راه خیلی ساده با Netlify
1. برو سایت netlify.com
2. ثبت‌نام کن یا با Google وارد شو.
3. بخش Add new site را بزن.
4. گزینه Deploy manually را انتخاب کن.
5. همین پوشه یا فایل `index.html` را Drag & Drop کن.
6. لینک سایتت ساخته می‌شود.

## راه با GitHub Pages
1. یک ریپازیتوری جدید بساز.
2. فایل `index.html` را آپلود کن.
3. از Settings > Pages، حالت Deploy from branch را فعال کن.
4. لینک سایت ساخته می‌شود.
